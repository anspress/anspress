<h1><?php _e('Error 404', 'ap'); ?></h1>
