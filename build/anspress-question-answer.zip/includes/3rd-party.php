<?php
/**
 * Third party plugin and theme hooks
 *
 * @package   AnsPress
 * @author    Rahul Aryan <support@anspress.io>
 * @license   GPL-2.0+
 * @link      http://anspress.io
 * @copyright 2014 Rahul Aryan
 */

class AnsPress_3rd_party
{
	public function __construct()
	{	

	}
}
