<div class="wrap">
	<h1>AnsPress Updates</h1>
		<table id="update-plugins-table" class="widefat">
			<thead>
				<tr>
					<th class="manage-column" scope="col"><label for="plugins-select-all"><?php _e('Actions', 'ap'); ?></label></th>
					<th class="manage-column" scope="col"></th>
				</tr>
			</thead>

			<tbody class="plugins">
				<tr>
					<td>
						<p>
							<strong><?php _e('Move old subscribers', 'ap'); ?></strong><br>
							<?php _e('Since 2.4 subscribers are stored in diffrent table, so move all subscribers data to new table.', 'ap'); ?>
						</p>
					</td>
					<td>
						<a class="button" href="#"><?php _e('Start', 'ap'); ?></a>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<strong><?php _e('Move old subscribers', 'ap'); ?></strong><br>
							<?php _e('Since 2.4 subscribers are stored in diffrent table, so move all subscribers data to new table.', 'ap'); ?>
						</p>
					</td>
					<td>
						<a class="button" href="#"><?php _e('Start', 'ap'); ?></a>
					</td>
				</tr>

			</table>
	</div>