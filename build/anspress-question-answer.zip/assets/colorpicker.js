jQuery(document).ready(function($){
   $('#question_label_field').wpColorPicker();
});